#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node* NodePointer;
typedef struct Node {
    int data;
    int leftThread;
    int rightThread;
    NodePointer leftChild;
    NodePointer rightChild;
} Node;

NodePointer root = NULL;
NodePointer createNode(int data);
void insertNode(int data);
void inorderTraversal(NodePointer root);
NodePointer getNode(int data);

int main() {
    FILE* input = fopen("input.txt", "r");
    if (input == NULL)
        printf("input file is error\n");

    int n, i = 0;
    fscanf(input, "%d", &n);
    NodePointer root = createNode(0); // �ʱ� ��Ʈ ��� ����

    int nodes[100];
    for (int i = 1; i <= 12; i++) {
        fscanf(input, "%d", &nodes[i]);
    }

    for (int i = 1; i <= 12; i++) {
        if (nodes[i] == 0) { // ����ִ� ����� ���
            continue;
        }

        // �θ� ����� �ε��� ���
        int parentIndex = i / 2;
        NodePointer parentNode = getNode(root, parentIndex);

        // ���ο� ��� ����
        NodePointer newNode = createNode(nodes[i]);

        // �θ� ���� ���ο� ��� ����
        if (i % 2 == 0) { // ���� �ڽ� ����� ���
            parentNode->leftChild = newNode;
        }
        else { // ������ �ڽ� ����� ���
            parentNode->rightChild = newNode;
        }
    }

    char op; int ndnum; char LR; int num;
    fscanf(input, "%c %d %c %d", &op, &ndnum, &LR, &num);
    if (op == '+') {
        NodePointer nodenum = getNode(root, ndnum);
        insertNode(nodenum, num, LR);
    }
    inorderTraversal(root);
    fclose(input);
    return 0;
}

NodePointer createNode(int data) {
    NodePointer newNode = (NodePointer)malloc(sizeof(Node));
    newNode->data = data;
    newNode->leftThread = 0;
    newNode->rightThread = 0;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    return newNode;
}

void insertNode(int data, NodePointer* node) {
    if (*node == NULL) {
        *node = (NodePointer)malloc(sizeof(Node));
        (*node)->data = data;
        (*node)->leftThread = 1;
        (*node)->rightThread = 1;
        (*node)->leftChild = NULL;
        (*node)->rightChild = NULL;
        return;
    }
    if (data < (*node)->data) {
        if ((*node)->leftThread) {
            NodePointer temp = (*node)->leftChild;
            (*node)->leftChild = (NodePointer)malloc(sizeof(Node));
            (*node)->leftThread = 0;
            (*node)->leftChild->data = data;
            (*node)->leftChild->leftChild = temp;
            (*node)->leftChild->leftThread = 1;
            (*node)->leftChild->rightChild = *node;
            (*node)->leftChild->rightThread = 1;
        }
        else {
            insertNode(data, &((*node)->leftChild));
        }
    }
    else {
        if ((*node)->rightThread) {
            NodePointer temp = (*node)->rightChild;
            (*node)->rightChild = (NodePointer)malloc(sizeof(Node));
            (*node)->rightThread = 0;
            (*node)->rightChild->data = data;
            (*node)->rightChild->rightChild = temp;
            (*node)->rightChild->rightThread = 1;
            (*node)->rightChild->leftChild = *node;
            (*node)->rightChild->leftThread = 1;
        }
        else {
            insertNode(data, &((*node)->rightChild));
        }
    }
}

NodePointer getNode(int data) {
    NodePointer newNode = (NodePointer)malloc(sizeof(Node));
    newNode->data = data;
    newNode->leftThread = 0;
    newNode->rightThread = 0;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    return newNode;
}

void inorderTraversal(NodePointer root) {
    NodePointer current = root;
    while (current->leftChild != NULL) {
        current = current->leftChild;
    }
    while (current != NULL) {
        printf("%d ", current->data);
        if (current->rightThread) {
            current = current->rightChild;
        }
        else {
            current = current->rightChild;
            while (current != NULL && !current->leftThread) {
                current = current->leftChild;
            }
        }
    }
    printf("\n");
}

