#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { not, and, or , true, false } logical;
typedef struct node* treePointer;
typedef struct node {
    logical data;
    int value;
    treePointer leftChild, rightChild;
} treeNode;

void postOrderEval(treePointer node);

int main() {
    FILE* input = fopen("input.txt", "r");
    if (input == NULL) {
        printf("Input file is error\n");
        return 0;
    }

    int n;
    fscanf(input, "%d", &n);
    int variableValues[25];

    int i = 0;
    while (!feof(input)) {
        char inputStr[10];
        fscanf(input, "%s", inputStr);
        if (strcmp(inputStr, "true") == 0) {
            variableValues[i] = 1;
        }
        else {
            variableValues[i] = 0;
        }
        i++;
    }i--;

    treePointer nodeArray[25];
    for (int j = 0; j < i; j++){
        nodeArray[j] = (treePointer)malloc(sizeof(treeNode));
        char inputStr[10];
        fscanf(input, "%s", inputStr);
        if (strcmp(inputStr, "not") == 0) {
            nodeArray[j]->data = not;
            nodeArray[j]->rightChild = nodeArray[j - 1];
            nodeArray[j - 1] = nodeArray[j];
            j--;
        }
        else {
            nodeArray[j]->data = (strcmp(inputStr, "and") == 0) ? and : or ;
            nodeArray[j]->rightChild = nodeArray[j - 1];
            nodeArray[j]->leftChild = nodeArray[j - 2];
            nodeArray[j - 2] = nodeArray[j];
            j -= 2;
        }
    }

    treePointer root = nodeArray[i-1];

    for (int j = 0; j < i; j++) {
        if (variableValues[j] == 1) {
            nodeArray[j]->data = true;
        }
        else {
            nodeArray[j]->data = false;
        }
    }

    postOrderEval(root);
    printf("result : %d\n", root->value);

    fclose(input);
    return 0;
}

void postOrderEval(treePointer node) {
    if (node) {
        postOrderEval(node->leftChild);
        postOrderEval(node->rightChild);
        switch (node->data) {
        case not:
            node->value = !node->rightChild->value;
            break;
        case and :
            node->value = node->rightChild->value && node->leftChild->value;
            break;
        case or :
            node->value = node->rightChild->value || node->leftChild->value;
            break;
        case true:
            node->value = 1;
            break;
        case false:
            node->value = 0;
            break;
        }
    }
}
