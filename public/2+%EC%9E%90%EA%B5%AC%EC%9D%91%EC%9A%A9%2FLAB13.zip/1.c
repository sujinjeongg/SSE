#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node* treePointer;
typedef struct Node {
    int data;
    treePointer left, right;
} Node;

Node* create_node(int data);
Node* build_tree(int* arr, int n, int i);
bool equal(Node* first, Node* second);

int main() {

    FILE* input1 = fopen("input1.txt", "r");
    int n1, i1 = 0;
    fscanf(input1, "%d", &n1);
    int* arr1 = (int*)malloc(n1 * sizeof(int));
    while (fscanf(input1, "%d", &arr1[i1]) != EOF) {
        if (arr1[i1] != -1)
            i1++;
    }i1--;
    Node* root1 = build_tree(arr1, i1, 0);
    fclose(input1);

    FILE* input2 = fopen("input2.txt", "r");
    int n2, i2 = 0;
    fscanf(input2, "%d", &n2);
    int* arr2 = (int*)malloc(n2 * sizeof(int));
    while (fscanf(input2, "%d", &arr2[i2]) != EOF) {
        if (arr2[i2] != -1)
            i2++;
    }i2--;
    Node* root2 = build_tree(arr2, i2, 0);
    fclose(input2);

    bool is_same = equal(root1, root2);

    if (is_same) {
        printf("The two binary trees are the same.\n");
    }
    else {
        printf("The two binary trees are not the same.\n");
    }

    return 0;
}

Node* create_node(int data) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

Node* build_tree(int* arr, int n, int i) {
    if (i >= n || arr[i] == -1) {
        return NULL;
    }
    Node* node = create_node(arr[i]);
    node->left = build_tree(arr, n, 2 * i + 1);
    node->right = build_tree(arr, n, 2 * i + 2);
    return node;
}

bool equal(Node* first, Node* second) {
    return ((!first && !second) || (first && second) && (first->data == second->data) &&
        equal(first->left, second->left) && equal(first->right, second->right));
}