#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct Node* NodePointer;
typedef struct Node {
    int data;
    int leftThread;
    int rightThread;
    NodePointer leftChild;
    NodePointer rightChild;
} Node;

NodePointer root = NULL;
NodePointer createNode(int data);
void insertNode(int data);
//void inorderTraversal(NodePointer root);
NodePointer getNode(int data);

int main() {
    FILE* input = fopen("input.txt", "r");
    if (input == NULL)
        printf("input file is error\n");

    int n, i = 0;
    fscanf(input, "%d", &n);
    NodePointer root = createNode(0); // �ʱ� ��Ʈ ��� ����

    int nodes[100];
    for (int i = 1; i <= 12; i++) {
        fscanf(input, "%d", &nodes[i]);
    }

    for (int i = 1; i <= 12; i++) {
        if (nodes[i] == 0) { // ����ִ� ����� ���
            continue;
        }

        // �θ� ����� �ε��� ���
        int parentIndex = i / 2;
        NodePointer parentNode = getNode(root, parentIndex);

        // ���ο� ��� ����
        NodePointer newNode = createNode(nodes[i]);

        // �θ� ���� ���ο� ��� ����
        if (i % 2 == 0) { // ���� �ڽ� ����� ���
            parentNode->leftChild = newNode;
        }
        else { // ������ �ڽ� ����� ���
            parentNode->rightChild = newNode;
        }
    }

    char op; int ndnum; char LR; int num;
    fscanf(input, "%c %d", &op, &ndnum);
    if (op == '-') {
        NodePointer nodenum = getNode(root, ndnum);
        deleteNode(ndnum, &root);
    }
    //inorderTraversal(root);
    fclose(input);
    return 0;
}

NodePointer createNode(int data) {
    NodePointer newNode = (NodePointer)malloc(sizeof(Node));
    newNode->data = data;
    newNode->leftThread = 0;
    newNode->rightThread = 0;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    return newNode;
}

void deleteNode(int data, NodePointer* node) {
    if (*node == NULL) {
        return;
    }
    if (data < (*node)->data) {
        deleteNode(data, &((*node)->leftChild));
    }
    else if (data > (*node)->data) {
        deleteNode(data, &((*node)->rightChild));
    }
    else { // data == (*node)->data
        if ((*node)->leftChild != NULL && (*node)->rightChild != NULL) {
            // Find the predecessor and exchange data
            NodePointer predecessor = (*node)->leftChild;
            while (!predecessor->rightThread) {
                predecessor = predecessor->rightChild;
            }
            (*node)->data = predecessor->data;
            deleteNode(predecessor->data, &((*node)->leftChild));
        }
        else {
            NodePointer temp = *node;
            if ((*node)->leftChild == NULL) {
                *node = (*node)->rightChild;
            }
            else {
                *node = (*node)->leftChild;
            }
            free(temp);
        }
    }
}

NodePointer getNode(int data) {
    NodePointer newNode = (NodePointer)malloc(sizeof(Node));
    newNode->data = data;
    newNode->leftThread = 0;
    newNode->rightThread = 0;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    return newNode;
}
/*
void inorderTraversal(NodePointer root) {
    NodePointer current = root;
    while (current->leftChild != NULL) {
        current = current->leftChild;
    }
    while (current != NULL) {
        printf("%d ", current->data);
        if (current->rightThread) {
            current = current->rightChild;
        }
        else {
            current = current->rightChild;
            while (current != NULL && !current->leftThread) {
                current = current->leftChild;
            }
        }
    }
    printf("\n");
}
*/
