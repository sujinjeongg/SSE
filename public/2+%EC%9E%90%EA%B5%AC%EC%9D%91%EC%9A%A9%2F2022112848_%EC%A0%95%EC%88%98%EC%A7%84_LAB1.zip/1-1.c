#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {
	int n;
	int sum = 0;

	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL) {
		printf("input1 file is error\n");
}
	fscanf(input1, "%d", &n);
	fclose(input1);

	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL) {
		printf("output1 file is error\n");
	}
	for (int i = 1; i <= n; i++) {
		sum += i;
	}
	fprintf(output1, "%d", sum);
	fclose(output1);

	return 0;
}
