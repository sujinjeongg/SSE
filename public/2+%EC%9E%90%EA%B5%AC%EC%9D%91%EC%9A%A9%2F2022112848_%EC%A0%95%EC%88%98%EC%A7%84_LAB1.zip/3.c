#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

#define MAX_SIZE 4

void matrix_multiplication(int n, int matrix1[][MAX_SIZE], int matrix2[][MAX_SIZE], int result[][MAX_SIZE]);

int main() {
    FILE* input3;
    input3 = fopen("input3.txt", "r");
    if (input3 == NULL) {
        printf("input3 file is error\n");
    }

    int n;
    int matrix1[MAX_SIZE][MAX_SIZE] = { 0, };
    int matrix2[MAX_SIZE][MAX_SIZE] = { 0, };
    int result[MAX_SIZE][MAX_SIZE] = { 0, };

    fscanf(input3, "%d", &n);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fscanf(input3, "%d", &matrix1[i][j]);
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fscanf(input3, "%d", &matrix2[i][j]);
        }
    }

    FILE* output3;
    output3 = fopen("output3.txt", "w");
    if (output3 == NULL) {
        printf("output3 file is error\n");
    }

    matrix_multiplication(n, matrix1, matrix2, result);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fprintf(output3, "%d ", result[i][j]);
        }
        fprintf(output3, "\n");
    }

    return 0;
}

void matrix_multiplication(int n, int matrix1[][MAX_SIZE], int matrix2[][MAX_SIZE], int result[][MAX_SIZE]) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                result[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }
}