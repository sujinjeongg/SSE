#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define COMPARE(x,y) (((x)<(y)) ? -1: ((x) == (y))?0:1)

int binsearch(int list[], int m, int left, int right);

int main() {
	int n;
	int m;

	FILE* input5;
	input5 = fopen("input5.txt", "r");
	if (input5 == NULL) {
		printf("input5 file is error\n");
	}
	fscanf(input5, "%d", &n);
	fscanf(input5, "%d", &m);

	int* list = (int*)malloc(sizeof(int) * n);
	for (int i = 0; i < n; i++) {
		fscanf(input5, "%d", &list[i]);
	}
	fclose(input5);

	int right = n - 1;
	int left = 0;

	FILE* output5;
	output5 = fopen("output5.txt", "w");
	if (output5 == NULL) {
		printf("output5 file is error\n");
	}

	int location = binsearch(list, m, left, right);
	fprintf(output5, "%d", location);

	return 0;
}

int binsearch(int list[], int m, int left, int right) {
	int middle;
	if (left <= right) {
		middle = (left + right) / 2;
		switch (COMPARE(list[middle], m)) {
		case -1: return binsearch(list, m, middle + 1, right);
		case 0: return middle;
		case 1: return binsearch(list, m, left, middle - 1);
		}
	}
	return -1;

}
