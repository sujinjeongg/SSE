#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define COMPARE(x,y) (((x)<(y)) ? 0: ((x) == (y))?1:2)

int binsearch(int list[], int m, int left, int right);

int main() {
	int n;
	int m;

	FILE* input4;
	input4 = fopen("input4.txt", "r");
	if (input4 == NULL) {
		printf("input4 file is error\n");
	}
	fscanf(input4, "%d", &n);
	fscanf(input4, "%d", &m);

	int* list = (int*)malloc(sizeof(int) * n);
	for (int i = 0; i < n; i++) {
		fscanf(input4, "%d", &list[i]);
	}

	int right = n - 1;
	int left = 0;

	FILE* output4;
	output4 = fopen("output4.txt", "w");
	if (output4 == NULL) {
		printf("output4 file is error\n");
	}

	int location = binsearch(list, m, left, right);
	fprintf(output4, "%d", location);

	return 0;
}

int binsearch(int list[], int m, int left, int right) {

	while (left <= right) {
		int middle = (left + right) / 2;

		switch ((m < list[middle]) ? 0 : (m == list[middle]) ? 1 : 2) {
		case 0:
			right = middle - 1;
			break;
		case 1:
			return middle;
		case 2:
			left = middle + 1;
		}
	}

}