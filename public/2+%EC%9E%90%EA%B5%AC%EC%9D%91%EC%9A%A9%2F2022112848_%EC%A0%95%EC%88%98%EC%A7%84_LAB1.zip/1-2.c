#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
	int n;
	int sum = 0;

	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL) {
		printf("input2 file is error\n");
	}
	fscanf(input2, "%d", &n);
	
	int* arr = (int*)malloc(sizeof(int) * n);
	for (int i = 0; i < n; i++) {
		fscanf(input2, "%d", &arr[i]);
		sum += arr[i];
	}
    fclose(input2);

    FILE* output2;
	output2 = fopen("output2.txt", "w");
	if (output2 == NULL) {
		printf("output2 file is error\n");
	}
	fprintf(output2, "%d", sum);
	fclose(output2);

	return 0;
}