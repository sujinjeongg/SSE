#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define MAX_QUEUE_SIZE 5

typedef struct {
	int front;
	int rear;
	int data[MAX_QUEUE_SIZE];
}Queue;

void error(char* message);
void init(Queue* q);
int is_empty(Queue* q);
int is_full(Queue* q);
void AddQ(Queue* q, int data);
int DeleteQ(Queue* q);
void List(Queue* q);

int main() {
	Queue q;
	init(&q);

	int menu = 0; int item = 0;
	while (1) {
		printf("\n\n***************************\n");
		printf("* 1. AddQ\t\t\t\t*\n");
		printf("* 2. DeleteQ\t\t\t*\n");
		printf("* 3. List\t\t\t\t*\n");
		printf("* 4. Exit\t\t\t\t*\n");
		printf("***************************\n");

		printf("Menu : ");
		scanf("%d", &menu);

		switch (menu) {
		case 1: {
			printf("AddQ Data : ");
			scanf("%d", &item);
			AddQ(&q, item); break;
		}
		case 2: {
			printf("DeleteQ Data : ");
			item = DeleteQ(&q);
			printf("%d\n", item); break;
		}
		case 3: {
			printf("List : ");
			List(&q);
			printf("\n\n"); break;
		}
		case 4: {
			printf("Exit");
			return 0; break;
		}
		}
	}
	return 0;
}

void error(char* message) {
	printf("%s\n", message);
	exit(1);
}

void init(Queue* q) {
	q->front = q->rear = -1;
}

int is_empty(Queue* q) {
	return q->rear == q->front;
}

int is_full(Queue* q) {
	return q->rear == MAX_QUEUE_SIZE - 1;
}

void AddQ(Queue* q, int data) {

	if (is_full(q)) {
		error("overflow"); return;
	}
	q->data[++(q->rear)] = data;
}

int DeleteQ(Queue* q) {
	if (is_empty(q)) {
		error("underflow"); return -1;
	}
	int item = q->data[++(q->front)];

	return item;
}

void List(Queue* q) {
	for (int i = 0; i < MAX_QUEUE_SIZE; i++) {
		if (i <= q->front || i > q->rear)
			printf("");
		else
			printf("%d ", q->data[i]);
	}
	printf("\n");
}
