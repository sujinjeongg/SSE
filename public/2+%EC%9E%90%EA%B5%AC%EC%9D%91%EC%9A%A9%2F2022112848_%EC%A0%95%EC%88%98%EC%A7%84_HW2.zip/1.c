#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	char arr[3][20];
	for (int i = 0; i < 3; i++)
		fgets(arr[i], 20, input1);

	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL)
		printf("output1 file is error\n");

	char(*ptr)[20] = arr;
	for (int i = 0; i < 3; i++)
		fprintf(output1, "%s", ptr[i]);

	return 0;
}