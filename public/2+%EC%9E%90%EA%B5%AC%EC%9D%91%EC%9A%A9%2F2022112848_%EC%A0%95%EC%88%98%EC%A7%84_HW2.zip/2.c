#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

int main() {
	int num[10] = { -1, }; //-1�� �ʱ�ȭȭ
	srand(time(NULL));
	for (int i = 0; i < 10; i++)
		num[i] = rand() % 25;

	int** arr;
	arr = (int**)malloc(sizeof(int*) * 5);

	for (int i = 0; i < 10; i++)
		arr[i] = (int*)malloc(sizeof(int) * 10);

	for (int i = 0; i < 5; i++) //-1�� �ʱ�ȭ
		for (int j = 0; j < 10; ++j)
			arr[i][j] = -1;

	int zero = 0, one = 0, two = 0, three = 0, four = 0;
	for (int i = 0; i < 10; i++) {
		if ((num[i] / 5) == 0) {
			arr[0][zero] = num[i];
			zero++;
		}
		else if ((num[i] / 5) == 1) {
			arr[1][one] = num[i];
			one++;
		}
		else if ((num[i] / 5) == 2) {
			arr[2][two] = num[i];
			two++;
		}
		else if ((num[i] / 5) == 3) {
			arr[3][three] = num[i];
			three++;
		}
		else if ((num[i] / 5) == 4) {
			arr[4][four] = num[i];
			four++;
		}
	}

	for (int i = 0; i < 5; i++) {//�ش� �ڸ����� ������ ���� ��� �ش� index�� ù ���ҿ� -1�� ����
		if ((sizeof(arr[i]) / sizeof(int)) == 0)
			arr[i][0] = -1;
	}

	arr[0] = (int*)realloc(arr[0], sizeof(int) * zero);
	arr[1] = (int*)realloc(arr[1], sizeof(int) * one);
	arr[2] = (int*)realloc(arr[2], sizeof(int) * two);
	arr[3] = (int*)realloc(arr[3], sizeof(int) * three);
	arr[4] = (int*)realloc(arr[4], sizeof(int) * four);

	int sum0 = 0, sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0;
	for (int i = 0; i < 5; i++) { //�� ���ϰ� ���
		if (i == 0) {
			printf("arr[%d] = ", i);
			for (int j = 0; j < zero; j++) {
				if (j != (zero - 1))
					printf("%d + ", arr[i][j]);
				else
					printf("%d = ", arr[i][j]);
				sum0 += arr[0][j];
			}
			printf("%d\n", sum0);
		}

		if (i == 1) {
			printf("arr[%d] = ", i);
			for (int j = 0; j < one; j++) {
				if (j != (one - 1))
					printf("%d + ", arr[i][j]);
				else
					printf("%d = ", arr[i][j]);
				sum1 += arr[1][j];
			}
			printf("%d\n", sum1);
		}

		if (i == 2) {
			printf("arr[%d] = ", i);
			for (int j = 0; j < two; j++) {
				if (j != (two - 1))
					printf("%d + ", arr[i][j]);
				else
					printf("%d = ", arr[i][j]);
				sum2 += arr[2][j];
			}
			printf("%d\n", sum2);
		}
		if (i == 3) {
			printf("arr[%d] = ", i);
			for (int j = 0; j < three; j++) {
				if (j != (three - 1))
					printf("%d + ", arr[i][j]);
				else
					printf("%d = ", arr[i][j]);
				sum3 += arr[3][j];
			}
			printf("%d\n", sum3);
		}
		if (i == 4) {
			printf("arr[%d] = ", i);
			for (int j = 0; j < four; j++) {
				if (j != (four - 1))
					printf("%d + ", arr[i][j]);
				else
					printf("%d = ", arr[i][j]);
				sum4 += arr[4][j];
			}
			printf("%d\n", sum4);
		}
	}

	for (int i = 0; i < 5; i++)
		free(arr[i]);
	free(arr);

	return 0;
}