#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define MAX_COL 50
#define COMPARE(x,y) x<y?-1:(x==y)?0:1

typedef struct {
	int row;
	int col;
	int value;
}term;

void FastTranspose(term arr[], term b[]);
void summ(term s[], int* total, int row, int col, int* sum);
void sparsematrix_mult(term arr[], term b[], term s[]);
void summ(term s[], int* total, int row, int col, int* sum) {
	if (*sum) {
		if (*total < MAX_COL) {
			s[++ * total].row = row;
			s[*total].col = col;
			s[*total].value = *sum;
			*sum = 0;
		}
		else {
			printf("���� �� �ʰ�\n");
			exit(1);
		}
	}
}

void sparsematrix_mult(term arr[], term b[], term s[]) {
	int col, i, j;
	int arr_rows = arr[0].row, arr_cols = arr[0].col, arr_total = arr[0].value;
	int b_cols = b[0].col, b_total = b[0].value;
	if (arr_cols != b[0].row) {
		printf("matrices error\n");
		exit(1);
	}
	term mult[MAX_COL];
	FastTranspose(b, mult);

	int mult_total = 0;
	int row = arr[1].row;
	int row_start = 1;
	int sum = 0;
	arr[arr_total + 1].row = arr_rows;
	mult[b_total + 1].row = b_cols;
	mult[b_total + 1].col = -1;

	for (int i = 1; i <= arr_total;) {
		col = mult[1].row;
		for (int j = 1; j <= mult_total + 1;) {
			if (arr[i].row != row) {
				summ(s, b_total, row, col, &sum);
				i = row_start;
				for (; mult[j].row == col; j++);
				col = mult[j].row;
			}
			else if (mult[j].row != col) {
				summ(s, mult_total, row, col, &sum);
				i = row_start;
				col = mult[j].row;
			}
			else
				switch (COMPARE(arr[i].col, mult[j].col)) {
				case -1:
					i++; break;
				case 0:
					sum += arr[i++].value * mult[j++].value;
					break;
				case 1:
					j++;
				}
		}
		for (; arr[i].row == row; i++);
		row_start = i;
		row = arr[i].row;
	}
	s[0].row = arr_rows;
	s[0].col = b_cols;
	s[0].value = mult_total;


}

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	int n = 0;
	fscanf(input1, "%d", &n);

	term arr[101];
	term b[101];
	term s[101];

	arr[0].row = n;
	arr[0].col = n;
	int num = 0;
	int count_value = 1;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			fscanf(input1, "%d", &num);
			if (num != 0) {
				arr[count_value].row = i;
				arr[count_value].col = j;
				arr[count_value].value = num;
				count_value++;
			}
		}
	}
	
	arr[0].value = count_value-1;
	//

	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL)
		printf("input2 file is error\n");

	int m = 0;
	fscanf(input2, "%d", &m);
	b[0].row = m;
	b[0].col = m;
	int numb = 0;
	int count_valueb = 1;

	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			fscanf(input2, "%d", &numb);
			if (numb != 0) {
				arr[count_valueb].row = i;
				arr[count_valueb].col = j;
				arr[count_valueb].value = numb;
				count_valueb++;
			}
		}
	}

	b[0].value = count_valueb - 1;
	//

	sparsematrix_mult(arr, b, s);

	FILE* output;
	output = fopen("output.txt", "w");
	if (output == NULL)
		printf("output file is error\n");

	fprintf(output, "%d\n", s[0].value);
	for (int i = 1; i <= count_value ; i++)
		fprintf(output, "%d %d %d\n", s[i].row, s[i].col, s[i].value);

	return 0;
}

void FastTranspose(term arr[], term b[]) {
	int row_list[MAX_COL];
	int startingpos[MAX_COL];
	int count_value = arr[0].value;
	int count_col = arr[0].col;

	b[0].row = count_col;
	b[0].col = arr[0].row;
	b[0].value = count_value;

	if (count_value > 0) {
		for (int i = 0; i < count_col; i++)
			row_list[i] = 0;

		for (int i = 1; i <= count_value; i++)
			row_list[arr[i].col]++;

		startingpos[0] = 1;

		for (int i = 1; i < count_col; i++)
			startingpos[i] = startingpos[i - 1] + row_list[i - 1];

		int k = 0;
		for (int i = 1; i < count_value; i++) {
			k = startingpos[arr[i].col]++;
			b[k].row = arr[i].col;
			b[k].col = arr[i].row;
			b[k].value = arr[i].value;
		}
	}
}