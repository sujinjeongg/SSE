#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define MAX_COL 9

typedef struct {
	int row;
	int col;
	int value;
}term;

void FastTranspose(term arr[], term b[]);

int main() {
	FILE* input;
	input = fopen("input.txt", "r");
	if (input == NULL)
		printf("input file is error\n");

	int n = 0;
	fscanf(input, "%d", &n);

	term arr[MAX_COL] = { NULL };
	term b[MAX_COL] = { NULL };

	arr[0].row = n;
	arr[0].col = n;
	int num = 0;
	int count_value = 1;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			fscanf(input, "%d", &num);
			if (num != 0) {
				arr[count_value].row = i;
				arr[count_value].col = j;
				arr[count_value].value = num;
				count_value++;
			}
		}
	}
	count_value--;
	arr[0].value = count_value;

	FastTranspose(arr, b);

	FILE* output;
	output = fopen("output.txt", "w");
	if (output == NULL)
		printf("output file is error\n");

	fprintf(output, "%d\n", arr[0].value);
	for (int i = 1; i <= count_value; i++)
		fprintf(output, "%d %d %d\n", b[i].row, b[i].col, b[i].value);

	return 0;
}

void FastTranspose(term arr[], term b[]) {
	int row_list[MAX_COL];
	int startingpos[MAX_COL];
	int count_value = arr[0].value;
	int count_col = arr[0].col;

	b[0].row = count_col;
	b[0].col = arr[0].row;
	b[0].value = count_value;

	if (count_value > 0) {
		for (int i = 0; i < count_col; i++)
			row_list[i] = 0;

		for (int i = 1; i <= count_value; i++)
			row_list[arr[i].col]++;

		startingpos[0] = 1;

		for (int i = 1; i < count_col; i++)
			startingpos[i] = startingpos[i - 1] + row_list[i - 1];

		int k = 0;
		for (int i = 1; i <= count_value; i++) {
			k = startingpos[arr[i].col]++;
			b[k].row = arr[i].col;
			b[k].col = arr[i].row;
			b[k].value = arr[i].value;
		}
	}
}