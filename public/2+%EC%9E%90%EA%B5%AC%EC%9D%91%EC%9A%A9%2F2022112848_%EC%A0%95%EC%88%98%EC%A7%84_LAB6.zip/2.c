#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define MAX_STACK 100
#define EOS 0

int top = -1;
int stack[MAX_STACK];

char push(char token);
int pop();
void convert(char* infix, char* postfix);
int isDigit(char token);
int priority(char token);
int stack_priority(char token);
int evaluate(char* postfix);

int main() {
	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL)
		printf("input1 file is error\n");

	char infix[50], postfix[50];
	fgets(infix, 50, input2);
	/*if (fgets(infix, 64, input2) != NULL)
		printf("%s\n", infix);*/

	convert(infix, postfix);

	FILE* output2;
	output2 = fopen("output2.txt", "w");
	if (output2 == NULL)
		printf("output2 file is error\n");

	fprintf(output2, "%s\n", postfix);
	fprintf(output2, "��� ���: %d\n", evaluate(postfix));

	return 0;
}

char push(char token) {
	if (MAX_STACK - 1 == top) {
		printf("stack is full\n");
		return 0;
	}
	stack[++top] = token;
}

int pop() {
	if (top < 0) {
		printf("stack is empty\n");
		return top;
	}
	return stack[top--];
}

void convert(char* infix, char* postfix) {
	int k = 0;
	char token;
	push(EOS);

	for (int i = 0; infix[i] != 0; i++) {
		token = infix[i];
		if (isDigit(token))
			postfix[k++] = token;
		else {
			if (token == ')') {
				do {
					postfix[k++] = pop();
				} while (postfix[k - 1] != '(');
				k--;
				continue;
			}
			while (stack_priority(stack[top]) >= priority(token))
				postfix[k++] = pop();
			push(token); //�� ������ ��� �ش��� �� �Ǵ� ������ stack�� ����
		}
	}
	do {
		postfix[k++] = pop(); //stack�� ����� �����ڸ� postfix�� ����
	} while (postfix[k - 1] != EOS);
}

int isDigit(char token) {
	if ('0' <= token && token <= '9')
		return 1;
	else
		return 0;
}

int priority(char token) { //infix �迭�� ������ �켱����
	switch (token) {
	case '(':
	case ')': return 10;
	case '/':
	case '*': return 7;
	case '+':
	case '-': return 6;
	case '<':
	case '>':
	case '<=':
	case '>=': return 5;
	case '==':
	case '!=': return 4;
	case '&&': return 3;
	case '||': return 2;
	}
}

int stack_priority(char token) { //stack �迭�� ������ �켱����
	switch (token) {
	case '(': return 1;
	case ')': return 10;
	case '/':
	case '*': return 7;
	case '+':
	case '-':return 6;
	case '<':
	case '>':
	case '<=':
	case '>=': return 5;
	case '==':
	case '!=': return 4;
	case '&&': return 3;
	case '||': return 2;
	}
}

int evaluate(char* postfix) {
	char token;
	char op1, op2;

	for (int i = 0; postfix[i] != 0; i++) {
		token = postfix[i];
		if (isDigit(token))
			push(token - '0'); //���ڸ� ������ ��ȯ
		else {
			op1 = pop(), op2 = pop();
			switch (token) {
			case '/': push(op2 / op1); break;
			case '*': push(op2 * op1); break;
			case '+': push(op2 + op1); break;
			case '-': push(op2 - op1); break;
			case '<':push(op2 < op1); break;
			case '>':push(op2 > op1); break;
			case '<=':push(op2 <= op1); break;
			case '>=': push(op2 >= op1); break;
			case '==':push(op2 == op1); break;
			case '!=': push(op2 != op1); break;
			case '&&': push(op2 && op1); break;
			case '||': push(op2 || op1); break;
			}
		}
	} //stack�� ��� ���� ����� ����Ǿ�����
	return pop(); //stack�� ����� ���� ��� ��ȯ
}