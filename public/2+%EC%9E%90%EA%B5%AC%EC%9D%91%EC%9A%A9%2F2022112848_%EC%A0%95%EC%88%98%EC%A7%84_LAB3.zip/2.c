#define _CRT_SECURE_NO_WARNINGS
#define COMPARE(x,y) (x>y)?'>':(x==y)?'=':'<'
#include <stdio.h>
#include <stdlib.h>

struct item {
	int coef;
	int exp;
};

void apply(int* avail, int coef, int exp);
void SumPoly(struct item* arr, int avail, int startA, int finishA, int startB, int finishB, int* startC, int* finishC);

struct item arr[101];

int main() {
	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL)
		printf("input2 file is error\n");

	int n = 0, m = 0;
	fscanf(input2, "%d", &n);
	fscanf(input2, "%d", &m);


	for (int i = 0; i < n + m; i++) {
		fscanf(input2, "%d", &arr[i].coef);
		fscanf(input2, "%d", &arr[i].exp);
	}

	int avail = n + m;
	int startC, finishC;
	SumPoly(arr, avail, 0, n - 1, n, n + m - 1, &startC, &finishC);

	FILE* output2;
	output2 = fopen("output2.txt", "w");
	if (output2 == NULL)
		printf("output2 file is error\n");

	for (int i = startC; i <= finishC; i++) {
		fprintf(output2, "%d %d\n", arr[i].coef, arr[i].exp);
	}

	return 0;
}

void apply(int* avail, int coef, int exp) {
	if (*avail > 101) {
		printf("���� ���� �ʰ�\n");
		exit(1);
	}
	arr[*avail].coef = coef;
	arr[(*avail)++].exp = exp;
}

void SumPoly(struct item* arr, int avail, int startA, int finishA, int startB, int finishB, int* startC, int* finishC) {
	int sum = 0;
	*startC = avail;
	while (startA <= finishA && startB <= finishB) {
		switch (COMPARE(arr[startA].exp, arr[startB].exp)) {
		case '>':
			apply(&avail, arr[startA].coef, arr[startA].exp);
			startA++; break;
		case '=':
			sum = arr[startA].coef + arr[startB].coef;
			if (sum != 0)
				apply(&avail, sum, arr[startA].exp);
			startA++; startB++; break;
		case '<':
			apply(&avail, arr[startB].coef, arr[startB].exp);
			startB++; break;
		}
	}
	for (; startA <= finishA; startA++)
		apply(&avail, arr[startA].coef, arr[startA].exp);
	for (; startB <= finishB; startB++)
		apply(&avail, arr[startB].coef, arr[startB].exp);
	*finishC = avail - 1;
}