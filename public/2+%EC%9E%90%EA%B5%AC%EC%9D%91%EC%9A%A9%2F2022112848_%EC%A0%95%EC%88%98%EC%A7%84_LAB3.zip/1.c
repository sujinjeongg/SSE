#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void SumPoly(int arr[][2], int avail, int startA, int finishA, int startB, int finishB, int *startC, int *finishC);

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	int n = 0, m = 0;
	fscanf(input1, "%d", &n);
	fscanf(input1, "%d", &m);

	int arr[20][2] = { NULL };

	for (int i = 0; i < n + m; i++) {
		fscanf(input1, "%d", &arr[i][0]);
	    fscanf(input1, "%d", &arr[i][1]);
    }
	
	int avail = n + m;
	int startA = 0;
	int startB = n;
	int finishA = n - 1;
	int finishB = (n + m) - 1;
	int startC = avail;
	int finishC = 0;

	SumPoly(arr, avail, startA, finishA, startB, finishB, &startC, &finishC);

	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL)
		printf("output1 file is error\n");
	
	for (int i = startC; i <= finishC; i++) {
		fprintf(output1, "%d %d\n", arr[i][0], arr[i][1]);
	}
		
	return 0;
}

void SumPoly(int arr[][2],int avail, int startA, int finishA, int startB,int finishB, int *startC, int *finishC) {
	*startC = avail;

	while (startA <= finishA && startB <= finishB) {
		if (arr[startA][1] > arr[startB][1]) {
			arr[avail][0] = arr[startA][0];
			arr[avail++][1] = arr[startA][1];
			startA++;
		}
		else if (arr[startA][1] == arr[startB][1]) {
			if (arr[startA][0] + arr[startB][0]) {
				arr[avail][0] = arr[startA][0] + arr[startB][0];
				arr[avail++][1] = arr[startA][1];
			}
			startA++; startB++;
		}
		else {
			arr[avail][0] = arr[startB][0];
			arr[avail++][1] = arr[startB][1];
			startB++;
		}
	}
		//���� �� �̵�
		for (; startA <= finishA; startA++) {
			arr[avail][0] = arr[startA][0];
			arr[avail++][1] = arr[startA][1];
		}
		for (; startB <= finishB; startB++) {
			arr[avail][0] = arr[startB][0];
			arr[avail++][1] = arr[startB][1];
		}
		*finishC = avail - 1;
}