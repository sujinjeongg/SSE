#define _CRT_SECURE_NO_WARNINGS
#define COMPARE(x,y) (x>y)?'>':(x==y)?'=':'<'
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

struct item {
	int coef;
	int exp;
};

struct item* arr; 

void apply(int avail, int coef, int exp) {
	if (avail > 101) {
		printf("���� ���� �ʰ�\n");
		exit(1);
	}
	arr[avail].coef = coef;
	arr[avail++].exp = exp;
}

void SumPoly(int avail, int startA, int finishA, int startB, int finishB, int* startC, int* finishC) {

	*startC = avail;
	while (startA <= finishA && startB <= finishB) {
		switch (COMPARE(arr[startA].exp, arr[startB].exp)) {
		case '>':
			apply(avail, arr[startA].coef, arr[startA].exp);
			startA++; break;
		case '=':
			if (arr[startA].coef + arr[startB].coef)
				apply(avail, arr[startA].coef + arr[startB].coef, arr[startA].exp);
			startA++; startB++; break;
		case '<':
			apply(avail, arr[startB].coef, arr[startB].exp);
			startB++; break;
		}
	}
		for (; startA <= finishB; startA++)
			apply(avail, arr[startA].coef, arr[startA].exp);
		for (; startB <= finishB; startB++)
			apply(avail, arr[startB].coef, arr[startB].exp);
		*finishC = avail - 1;
}

int main() {
	arr =  malloc(sizeof(struct item));
	FILE* input3;
	input3 = fopen("input3.txt", "r");
	if (input3 == NULL)
		printf("input3 file is error\n");

	int n = 0, m = 0;
	fscanf(input3, "%d", &n);
	fscanf(input3, "%d", &m);

	for (int i = 0; i < n + m; i++) {
		fscanf(input3, "%d", &arr[i].coef);
		fscanf(input3, "%d", &arr[i].exp);
	}

	int avail = n + m;
	int *startC, *finishC;
	SumPoly(avail, 0, n - 1, n, n + m - 1, &startC, &finishC);

	FILE* output3;
	output3 = fopen("output3.txt", "w");
	if (output3 == NULL)
		printf("output3 file is error\n");

	for (int i = startC; i <= finishC; i++) {
		fprintf(output3, "%d %d\n", arr[i].coef, arr[i].exp);
		//printf("%d %d\n", arr[i].coef, arr[i].exp);
	}

	free(arr);
	return 0;
}