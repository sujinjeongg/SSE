#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define MAX_STACK_SIZE 100
#define TRUE 1
#define FALSE 0

typedef struct {
	int x;
	int y;
}offsets;
offsets move[8] = { {-1,0},{-1,1},{0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1 } };

typedef struct {
	int row;
	int col;
	int dir;
}data;

data stack[MAX_STACK_SIZE];

void path(void);
void push(int* top, data pos);
data pop(int* top);

int top;
int maze[7][7];
int mark[7][7] = { NULL };
int n = 5, m = 5;

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	fscanf(input1, "%d", &n);
	fscanf(input1, "%d", &m);

	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			fscanf(input1, "%d", &maze[i][j]);

	path();


	return 0;
}

void path(void) {

	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL)
		printf("output1 file is error\n");

	int i, j, row, col, nextRow, nextCol, dir, count = 0;
	int found = FALSE;
	data pos;
	mark[1][1] = 1;
	top = 0;
	stack[0].row = 1; stack[0].col = 1; stack[0].dir = 1;

	while (top > -1 && !found) {
		pos = pop(&top);
		row = pos.row; col = pos.col; dir = pos.dir;
		while (dir < 8 && !found) {
			nextRow = row + move[dir].x;
			nextCol = col + move[dir].y;
			if (nextRow == n && nextCol == m) {
				found = TRUE;
			}
			else if (!maze[nextRow][nextCol] && !mark[nextRow][nextCol]) {
				mark[nextRow][nextCol] = 1;
				pos.row = row; pos.col = col; pos.dir = ++dir;
				push(&top, pos);
				row = nextRow;
				col = nextCol;
				dir = 0;
			}
			else
				++dir;
		}
	}

	if (found) {
		printf("success\n");
		printf("path�� ");
		for (i = 0; i <= top; i++) {
			count++;
			printf( "(%d, %d) ", stack[i].row, stack[i].col);
		}
		printf( "(%d, %d) ", row, col);
		printf( "(%d, %d) ", n, m);
		printf( "����� ������ ũ�� / ������ �ִ� ũ�� = %d / %d\n", count, n * m);
	}
	else
		printf("fail\n");
}

void push(int* top, data pos) {
	(*top)++;
	stack[*top].row = pos.row;
	stack[*top].col = pos.col;
	stack[*top].dir = pos.dir;
}

data pop(int* top) {
	data result;
	if (&top < 0)
		printf("empty stack\n");
	else {
		result = stack[*top];
		(*top)--;
	}
	return result;
}
