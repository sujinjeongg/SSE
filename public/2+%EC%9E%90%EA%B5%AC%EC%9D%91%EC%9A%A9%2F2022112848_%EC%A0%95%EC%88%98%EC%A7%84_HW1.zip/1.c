#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

typedef struct info {
	int num;
	char name[20];
	double first;
	double second;
	double sum;
}info;

info people[6] = { NULL };

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	for (int i = 1; i <= 6; i++) {
		fscanf(input1, "%d", &people[i].num);
		fscanf(input1, "%s", &people[i].name);
		fscanf(input1, "%.1lf", &people[i].first);
		fscanf(input1, "%.1lf", &people[i].second);
	}

	int sum = 0;
	for (int i = 1; i <= 6; i++)
		people[i].sum = people[i].first + people[i].second;

	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL)
		printf("output1 file is error\n");

	for (int i = 1; i <= 6; i++) {
		fprintf(output1, "%d %s %.1lf %.1lf %.1lf\n", people[i].num, people[i].name, people[i].first, people[i].second, people[i].sum);
	}
	return 0;
}