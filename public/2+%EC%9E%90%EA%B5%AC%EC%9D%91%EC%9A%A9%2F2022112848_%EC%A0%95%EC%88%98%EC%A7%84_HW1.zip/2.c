#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL)
		printf("input2 file is error\n");

	int* num = (int*)malloc(sizeof(int) * 1);
	char* name = (char*)malloc(sizeof(char) * 1);
	double* first = (double*)malloc(sizeof(double) * 1);
	double* second = (double*)malloc(sizeof(double) * 1);
	fscanf(input2, "%d", &num[1]);
	fscanf(input2, "%s", &name[1]);
	fscanf(input2, "%.1lf", &first[1]);
	fscanf(input2, "%.1lf", &second[1]);
	

	for (int i = 2; i <= 6; i++) {
		realloc(num, sizeof(int) * (i));
		fscanf(input2, "%d", &num[i]);
		realloc(name, sizeof(char) * (i));
		fscanf(input2, "%s", &name[i]);
		realloc(first, sizeof(double) * (i));
		fscanf(input2, "%.1lf", &first[i]);
		realloc(second, sizeof(double) * (i));
		fscanf(input2, "%.1lf", &second[i]);
	}
	free(num);
	free(name);
	free(first);
	free(second);

	FILE* output2;
	output2 = fopen("output1.txt", "w");
	if (output2 == NULL)
		printf("output2 file is error\n");

	int sum = 0;
	for (int i = 1; i <= 6; i++) {
		sum = first[i] + second[i];
		fprintf(output2, "%d %s %.1lf %.1lf %.1lf\n", num[i], name[i], first[i], second[i], sum);
	}
	return 0;
}