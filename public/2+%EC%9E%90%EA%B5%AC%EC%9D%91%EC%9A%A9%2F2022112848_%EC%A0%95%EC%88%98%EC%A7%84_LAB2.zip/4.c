#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main() {
	struct account{
		int accountNum;
		char name[30];
		int deposit;
		int loan; // �����
	};

	struct account people[5];

	FILE* input4;
	input4 = fopen("input4.txt", "r");
	if (input4 == NULL)
		printf("input4 file is error\n");

	for (int i = 0; i < 5; i++) {
		fscanf(input4, "%d", &people[i].accountNum);
		fscanf(input4, "%s", &people[i].name);
		fscanf(input4, "%d", &people[i].deposit);
		fscanf(input4, "%d", &people[i].loan);
	}

	FILE* output4;
	output4 = fopen("output4.txt", "w");
	if (output4 == NULL)
		printf("output4 file is error\n");

	int max = 0;
	int i ;
	for (i=1; i <5;i++) {
		if (people[max].loan < people[i].loan) {
			max = i;
		}
	}

	fprintf(output4, "%d %s %d %d\n", people[max].accountNum, people[max].name, people[max].deposit, people[max].loan);
	return 0;
}