#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	FILE* input3;
	input3 = fopen("input3.txt", "r");
	if (input3 == NULL)
		printf("input3 file is error\n");

    char** str = malloc(sizeof(char*) * 2);
	for (int i = 0; i < 2; i++)
		str[i] = malloc(sizeof(char) * 16);

	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 16; j++)
			fscanf(input3, "%c", &str[i][j]);

	FILE* output3;
	output3 = fopen("output3.txt", "w");
	if (output3 == NULL)
		printf("output3 file is error\n");

	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 16 ; j++)
			fprintf(output3, "%c", str[i][j]);
    
	for (int i = 0; i < 2; i++)
		free(str[i]);
	free(str);

	return 0;
}