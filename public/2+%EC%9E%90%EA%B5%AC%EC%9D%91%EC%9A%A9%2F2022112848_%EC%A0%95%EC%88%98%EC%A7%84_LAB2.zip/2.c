#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int main() {
	FILE* input2;
	input2 = fopen("input2.txt", "r");
	if (input2 == NULL)
		printf("input2 file is error\n");

	int n = 0;
	fscanf(input2, "%d", &n);
	double* arr = (double*)malloc(sizeof(double) * n);
	for (int i = 0; i < n; i++)
		fscanf(input2, "%lf", &arr[i]);

	FILE* output2;
	output2 = fopen("output2.txt", "w");
	if (output2 == NULL)
		printf("output2 file is error\n");

	for (int i = 0; i < n; i++)
		if ((arr[i] - (int)arr[i]) != 0)
			fprintf(output2, "%.1lf ", arr[i]);

	return 0;
}