#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

void MatrixAddition(int n, int m, int** arr1, int** arr2);

int main() {
	FILE* input1;
	input1 = fopen("input1.txt", "r");
	if (input1 == NULL)
		printf("input1 file is error\n");

	int n = 0, m = 0;
	fscanf(input1, "%d", &n);
	fscanf(input1, "%d", &m);

	//arr1
	int** arr1 = (int**)malloc(sizeof(int*) * n);
	for (int i = 0; i < n; i++)
		arr1[i] = (int*)malloc(sizeof(int) * m);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			fscanf(input1, "%d", &arr1[i][j]);

	//arr2
	int** arr2 = (int**)malloc(sizeof(int*) * n);
	for (int i = 0; i < n; i++)
		arr2[i] = (int*)malloc(sizeof(int) * m);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			fscanf(input1, "%d", &arr2[i][j]);

	//matrix addtion
	MatrixAddition(n, m, arr1, arr2);

    for (int i = 0; i < n; i++)
		free(arr1[i]);
	free(arr1);
	for (int i = 0; i < n; i++)
		free(arr2[i]);
	free(arr2);

	return 0;
}

void MatrixAddition(int n, int m, int** arr1, int** arr2) {
	FILE* output1;
	output1 = fopen("output1.txt", "w");
	if (output1 == NULL)
		printf("output1 file is error\n");

	int** result_arr = (int**)malloc(sizeof(int*) * n);
	for (int i = 0; i < n; i++)
		result_arr[i] = (int*)malloc(sizeof(int) * m);

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			result_arr[i][j] = arr1[i][j] + arr2[i][j];

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			if ((j % (m - 1) == 0) && (j != 0))
				fprintf(output1, "%d\n", result_arr[i][j]);
			else
				fprintf(output1, "%d ", result_arr[i][j]);
		}

	for (int i = 0; i < n; i++)
		free(result_arr[i]);
	free(result_arr);
}